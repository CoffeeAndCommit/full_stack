from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('members/', views.members, name='members'),
    path('members/details/<int:id>', views.details, name='details'),
    path('details/<int:id>', views.details, name='details'),
    path('testing/', views.testing, name='testing'),  
    path('first_name/', views.first_name, name='first_name') ,
    path('order_by/', views.order_by, name='order_by')

]